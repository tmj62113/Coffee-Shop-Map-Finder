class Helper {
	static baseURL(){
		return "https://api.foursquare.com/v2";
	}
	static auth(){
		const keys = {
			client_id:"4HNSDVOSVJCPHZ43VMERH5HBOG34GNFKKHNT0L4TFCX2CHEA",
			client_secret:"K50SCVIQG3MCEW2N0GOGHN5SWZNZOZ24X0JHIURGALSXA2QS",
			v:"20181113"
		};
		return Object.keys(keys)
		.map(key => `${key}=${keys[key]}`)
		.join("&");
	}
	static urlBuilder(urlPrams){
		if (!urlPrams) {
			return"";
		}
		return Object.keys(urlPrams)
			.map(key => `${key}=${urlPrams[key]}`)
			.join("&");
	}
	static headers() {
		return {
			Accept: "application/json"
		};
	}
	static simpleFetch(endPoint, method, urlPrams) {
		let requestData = {
			method,
			headers: Helper.headers()
		};
	return fetch(
		`${Helper.baseURL()}${endPoint}?${Helper.auth()}&${Helper.urlBuilder(
			urlPrams
			)}`,
			requestData
		).then(res => res.json());
	}
}
export default class SquareAPI {
	static search(urlPrams) {
		return Helper.simpleFetch("/venues/search", "GET", urlPrams);
	}
	static getVenueDetails(Venue_ID) {
		return Helper.simpleFetch(`/venues/${Venue_ID}`, "GET");
	}
	static getVenuePhotos(Venue_ID) {
		return Helper.simpleFetch(`/venues/${Venue_ID}/photos`, "GET");
	}
}
